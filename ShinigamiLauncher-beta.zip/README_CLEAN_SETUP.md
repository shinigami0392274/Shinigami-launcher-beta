# Shinigami Clean Setup

Esta edición está diseñada para que el usuario final tenga una instalación limpia.

## Experiencia final

Después de compilar una vez con el builder, la carpeta `Release` contiene solamente:

`ShinigamiSetup.exe`

El usuario final:
1. Hace doble clic en `ShinigamiSetup.exe`.
2. No aparece CMD.
3. Elige Español o English.
4. Ve una interfaz frontal con logo/imagen morada.
5. Puede elegir acceso directo de Escritorio y menú Inicio.
6. Instala Shinigami Launcher.
7. Puede iniciarlo inmediatamente.

## .NET

Tanto el launcher como el instalador se publican como **self-contained**.
Por eso el usuario final normalmente no necesita instalar .NET.

Solo la persona que COMPILA el proyecto necesita .NET 8 SDK.
`Build Clean Release.vbs` ejecuta el builder sin mostrar CMD.
Si falta .NET 8 SDK, el builder muestra una ventana y ofrece instalarlo con WinGet
o abrir la página oficial de Microsoft.

## Crear la versión final

Haz doble clic en:

`Build Clean Release.vbs`

Cuando termine, ve a:

`Release\ShinigamiSetup.exe`

Ese es el archivo que debes distribuir.

## SmartScreen / Smart App Control

El instalador no intenta saltarse protecciones de Windows.
Para reducir advertencias al distribuir públicamente, firma `ShinigamiSetup.exe`
con un certificado Authenticode confiable.


## Builder corregido

Usa:

`Build Shinigami Setup.vbs`

Ahora aparece inmediatamente una ventana gráfica llamada **Shinigami Builder**.
No muestra CMD, pero sí enseña:
- estado actual,
- barra de progreso,
- log de compilación,
- errores,
- botón **Abrir Release** cuando termina.

Si algo falla también se guarda:
`build_log.txt`


## v2 fix
Corregido error CS0111 por `Main()` duplicado en el instalador WPF.
