namespace ShinigamiLauncher;

public partial class App : System.Windows.Application
{
}
