using Microsoft.Win32;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ShinigamiLauncher;

public partial class MainWindow : Window
{
    private DirectoryInfo? _versionDir;
    private string? _selectedExternalFont;

    private readonly Dictionary<string, Dictionary<string, string>> _presets = new()
    {
        ["Default"] = new(),
        ["Performance"] = new()
        {
            ["DFFlagTextureQualityOverrideEnabled"] = "True",
            ["DFIntTextureQualityOverride"] = "0",
            ["FIntDebugForceMSAASamples"] = "1",
            ["FIntFRMMaxGrassDistance"] = "0",
            ["FIntFRMMinGrassDistance"] = "0",
            ["DFFlagDisableDPIScale"] = "True"
        },
        ["Potato Extreme"] = new()
        {
            ["DFFlagTextureQualityOverrideEnabled"] = "True",
            ["DFIntTextureQualityOverride"] = "0",
            ["FIntDebugForceMSAASamples"] = "1",
            ["FIntFRMMaxGrassDistance"] = "0",
            ["FIntFRMMinGrassDistance"] = "0",
            ["DFFlagDisableDPIScale"] = "True",
            ["DFIntDebugFRMQualityLevelOverride"] = "1",
            ["DFIntCSGLevelOfDetailSwitchingDistance"] = "1",
            ["DFIntCSGLevelOfDetailSwitchingDistanceL12"] = "0",
            ["DFIntCSGLevelOfDetailSwitchingDistanceL23"] = "0",
            ["DFIntCSGLevelOfDetailSwitchingDistanceL34"] = "0"
        }
    };

    public MainWindow()
    {
        InitializeComponent();

        _presets["Performance + No Shake"] = new(_presets["Performance"])
        {
            ["FFlagDisableAllCameraShake"] = "True",
            ["FFlagDisableCameraShake"] = "True",
            ["FFlagDisableCameraShakeEffects"] = "True"
        };

        _presets["Potato + No Shake"] = new(_presets["Potato Extreme"])
        {
            ["FFlagDisableAllCameraShake"] = "True",
            ["FFlagDisableCameraShake"] = "True",
            ["FFlagDisableCameraShakeEffects"] = "True"
        };

        RendererCombo.SelectedIndex = 0;

        DetectRoblox();
        LoadSystemFonts();
        RefreshRobloxFonts();
        UpdatePresetPreview();
        ReadFpsInternal(false);
        LoadMultipleInstanceState();
    }

    // ---------------- Paths ----------------

    private static string LocalAppData =>
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

    private static string RobloxRoot =>
        Path.Combine(LocalAppData, "Roblox");

    private static string VersionsRoot =>
        Path.Combine(RobloxRoot, "Versions");

    private static string GlobalSettingsPath =>
        Path.Combine(RobloxRoot, "GlobalBasicSettings_13.xml");

    private string? ClientSettingsPath =>
        _versionDir == null
            ? null
            : Path.Combine(_versionDir.FullName, "ClientSettings", "ClientAppSettings.json");

    private string? RobloxFontsPath =>
        _versionDir == null
            ? null
            : Path.Combine(_versionDir.FullName, "content", "fonts");

    // ---------------- Navigation ----------------

    private void ShowPage(FrameworkElement page)
    {
        foreach (var p in new[]
        {
            HomePage, EnginePage, PresetsPage, FlagsPage,
            FontsPage, ModsPage, IntegrationsPage, SettingsPage
        })
            p.Visibility = Visibility.Collapsed;

        page.Visibility = Visibility.Visible;
    }

    private void NavHome_Click(object sender, RoutedEventArgs e) => ShowPage(HomePage);
    private void NavEngine_Click(object sender, RoutedEventArgs e) => ShowPage(EnginePage);
    private void NavPresets_Click(object sender, RoutedEventArgs e) => ShowPage(PresetsPage);
    private void NavFlags_Click(object sender, RoutedEventArgs e) => ShowPage(FlagsPage);
    private void NavFonts_Click(object sender, RoutedEventArgs e) => ShowPage(FontsPage);
    private void NavMods_Click(object sender, RoutedEventArgs e) => ShowPage(ModsPage);
    private void NavIntegrations_Click(object sender, RoutedEventArgs e) => ShowPage(IntegrationsPage);
    private void NavSettings_Click(object sender, RoutedEventArgs e) => ShowPage(SettingsPage);

    // ---------------- Roblox detection ----------------

    private void DetectRoblox()
    {
        _versionDir = null;

        if (Directory.Exists(VersionsRoot))
        {
            _versionDir = new DirectoryInfo(VersionsRoot)
                .GetDirectories("version-*")
                .Where(d => File.Exists(Path.Combine(d.FullName, "RobloxPlayerBeta.exe")))
                .OrderByDescending(d => File.GetLastWriteTimeUtc(Path.Combine(d.FullName, "RobloxPlayerBeta.exe")))
                .FirstOrDefault();
        }

        if (_versionDir != null)
        {
            SidebarStatus.Text = $"Roblox: Detectado\nVersión: {_versionDir.Name}\nLauncher: Listo";
            InstallPathText.Text = _versionDir.FullName;
        }
        else
        {
            SidebarStatus.Text = "Roblox: No detectado\nLauncher: Listo";
            InstallPathText.Text = "No detectado";
        }
    }

    private bool RequireRoblox()
    {
        if (_versionDir != null) return true;
        DetectRoblox();

        if (_versionDir == null)
        {
            MessageBox.Show("No encontré RobloxPlayerBeta.exe.", "Shinigami Launcher");
            return false;
        }
        return true;
    }

    private void DetectRoblox_Click(object sender, RoutedEventArgs e)
    {
        DetectRoblox();
        RefreshRobloxFonts();
    }

    private void LaunchRoblox_Click(object sender, RoutedEventArgs e)
    {
        if (!RequireRoblox()) return;

        var exe = Path.Combine(_versionDir!.FullName, "RobloxPlayerBeta.exe");
        Process.Start(new ProcessStartInfo(exe) { UseShellExecute = true });
    }

    private void OpenRobloxFolder_Click(object sender, RoutedEventArgs e)
    {
        if (!RequireRoblox()) return;
        OpenFolder(_versionDir!.FullName);
    }

    private void OpenContent_Click(object sender, RoutedEventArgs e)
    {
        if (!RequireRoblox()) return;
        OpenFolder(Path.Combine(_versionDir!.FullName, "content"));
    }

    private void OpenFonts_Click(object sender, RoutedEventArgs e)
    {
        if (!RequireRoblox()) return;
        OpenFolder(Path.Combine(_versionDir!.FullName, "content", "fonts"));
    }

    private static void OpenFolder(string path)
    {
        Directory.CreateDirectory(path);
        Process.Start(new ProcessStartInfo("explorer.exe", $"\"{path}\"") { UseShellExecute = true });
    }

    // ---------------- Backups ----------------

    private static string BackupRoot(string category) =>
        Path.Combine(RobloxRoot, "ShinigamiLauncherBackups", category);

    private static void BackupFile(string path, string category)
    {
        if (!File.Exists(path)) return;

        var dir = BackupRoot(category);
        Directory.CreateDirectory(dir);

        var dest = Path.Combine(
            dir,
            $"{DateTime.Now:yyyyMMdd_HHmmss}_{Path.GetFileName(path)}"
        );

        File.Copy(path, dest, true);
    }

    private static string? LatestBackup(string filename, string category)
    {
        var dir = BackupRoot(category);
        if (!Directory.Exists(dir)) return null;

        return Directory.GetFiles(dir, $"*_{filename}")
            .OrderByDescending(File.GetLastWriteTimeUtc)
            .FirstOrDefault();
    }

    // ---------------- FPS ----------------

    private void ApplyFps_Click(object sender, RoutedEventArgs e)
    {
        if (!int.TryParse(FpsTextBox.Text.Trim(), out var fps) || fps < 0 || fps > 99999)
        {
            MessageBox.Show("Escribe un número entre 0 y 99999.", "Shinigami Launcher");
            return;
        }

        if (!File.Exists(GlobalSettingsPath))
        {
            MessageBox.Show(
                "No existe GlobalBasicSettings_13.xml.\n\nAbre Roblox una vez, ciérralo y vuelve a intentarlo.",
                "Shinigami Launcher"
            );
            return;
        }

        var text = File.ReadAllText(GlobalSettingsPath);
        const string pattern = @"(<int\s+name=[""']FramerateCap[""']\s*>\s*)(-?\d+)(\s*</int>)";

        if (!Regex.IsMatch(text, pattern, RegexOptions.IgnoreCase))
        {
            MessageBox.Show("No encontré FramerateCap en GlobalBasicSettings_13.xml.", "Shinigami Launcher");
            return;
        }

        BackupFile(GlobalSettingsPath, "GlobalBasicSettings");

        var updated = Regex.Replace(
            text,
            pattern,
            m => $"{m.Groups[1].Value}{fps}{m.Groups[3].Value}",
            RegexOptions.IgnoreCase
        );

        File.WriteAllText(GlobalSettingsPath, updated);
        ReadFpsInternal(false);

        MessageBox.Show($"FramerateCap cambiado a {fps}.", "Shinigami Launcher");
    }

    private void ReadFps_Click(object sender, RoutedEventArgs e) => ReadFpsInternal(true);

    private void ReadFpsInternal(bool updateBox)
    {
        if (!File.Exists(GlobalSettingsPath))
        {
            FpsStatusText.Text = "GlobalBasicSettings_13.xml todavía no existe.";
            return;
        }

        var text = File.ReadAllText(GlobalSettingsPath);
        var m = Regex.Match(
            text,
            @"<int\s+name=[""']FramerateCap[""']\s*>\s*(-?\d+)\s*</int>",
            RegexOptions.IgnoreCase
        );

        if (!m.Success)
        {
            FpsStatusText.Text = "No encontré FramerateCap.";
            return;
        }

        if (updateBox)
            FpsTextBox.Text = m.Groups[1].Value;

        FpsStatusText.Text = $"Valor actual detectado: {m.Groups[1].Value} FPS";
    }

    private void RestoreGlobalSettings_Click(object sender, RoutedEventArgs e)
    {
        var backup = LatestBackup(Path.GetFileName(GlobalSettingsPath), "GlobalBasicSettings");
        if (backup == null)
        {
            MessageBox.Show("No hay backup de GlobalBasicSettings.", "Shinigami Launcher");
            return;
        }

        File.Copy(backup, GlobalSettingsPath, true);
        ReadFpsInternal(false);
        MessageBox.Show("GlobalBasicSettings restaurado.", "Shinigami Launcher");
    }

    // ---------------- FastFlags ----------------

    private static string ToJson(Dictionary<string, string> data) =>
        JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });

    private void WriteFlags(Dictionary<string, string> data)
    {
        if (!RequireRoblox()) return;

        var path = ClientSettingsPath!;
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        BackupFile(path, "FastFlags");

        File.WriteAllText(path, ToJson(data));
        MessageBox.Show("ClientAppSettings.json actualizado.", "Shinigami Launcher");
    }

    private Dictionary<string, string> ReadFlagsDictionary()
    {
        if (!RequireRoblox()) return new();
        var path = ClientSettingsPath!;
        if (!File.Exists(path)) return new();

        var json = File.ReadAllText(path);
        return JsonSerializer.Deserialize<Dictionary<string, string>>(json) ?? new();
    }

    private void QuickPerformance_Click(object sender, RoutedEventArgs e) =>
        WriteFlags(new Dictionary<string, string>(_presets["Performance"]));

    private void QuickPotato_Click(object sender, RoutedEventArgs e) =>
        WriteFlags(new Dictionary<string, string>(_presets["Potato Extreme"]));

    private void QuickNoShake_Click(object sender, RoutedEventArgs e)
    {
        var flags = ReadFlagsDictionary();
        flags["FFlagDisableAllCameraShake"] = "True";
        flags["FFlagDisableCameraShake"] = "True";
        flags["FFlagDisableCameraShakeEffects"] = "True";
        WriteFlags(flags);
    }

    private void RestoreFlagsBackup_Click(object sender, RoutedEventArgs e)
    {
        if (!RequireRoblox()) return;

        var path = ClientSettingsPath!;
        var backup = LatestBackup(Path.GetFileName(path), "FastFlags");

        if (backup == null)
        {
            MessageBox.Show("No hay backup de FastFlags.", "Shinigami Launcher");
            return;
        }

        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.Copy(backup, path, true);
        MessageBox.Show("FastFlags restauradas.", "Shinigami Launcher");
    }

    private void PresetCombo_SelectionChanged(object sender, SelectionChangedEventArgs e) =>
        UpdatePresetPreview();

    private string SelectedPresetName()
    {
        if (PresetCombo.SelectedItem is ComboBoxItem item)
            return item.Content?.ToString() ?? "Performance";
        return "Performance";
    }

    private void UpdatePresetPreview()
    {
        if (PresetPreview == null) return;
        var name = SelectedPresetName();
        if (_presets.TryGetValue(name, out var data))
            PresetPreview.Text = ToJson(data);
    }

    private void ApplyPreset_Click(object sender, RoutedEventArgs e)
    {
        var name = SelectedPresetName();
        if (_presets.TryGetValue(name, out var data))
            WriteFlags(new Dictionary<string, string>(data));
    }

    private void ReadFlags_Click(object sender, RoutedEventArgs e)
    {
        FlagsEditor.Text = ToJson(ReadFlagsDictionary());
    }

    private void ValidateFlags_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var data = JsonSerializer.Deserialize<Dictionary<string, string>>(FlagsEditor.Text);
            MessageBox.Show($"JSON válido. {data?.Count ?? 0} ajustes.", "Shinigami Launcher");
        }
        catch (Exception ex)
        {
            MessageBox.Show($"JSON inválido:\n{ex.Message}", "Shinigami Launcher");
        }
    }

    private void ApplyFlags_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var data = JsonSerializer.Deserialize<Dictionary<string, string>>(FlagsEditor.Text)
                       ?? new Dictionary<string, string>();
            WriteFlags(data);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"JSON inválido:\n{ex.Message}", "Shinigami Launcher");
        }
    }

    private void ImportJson_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog { Filter = "JSON (*.json)|*.json|Todos (*.*)|*.*" };
        if (dlg.ShowDialog() == true)
            FlagsEditor.Text = File.ReadAllText(dlg.FileName);
    }

    private void ExportJson_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new SaveFileDialog { Filter = "JSON (*.json)|*.json", DefaultExt = ".json" };
        if (dlg.ShowDialog() == true)
            File.WriteAllText(dlg.FileName, FlagsEditor.Text);
    }

    private void ClearFlags_Click(object sender, RoutedEventArgs e)
    {
        if (!RequireRoblox()) return;

        var path = ClientSettingsPath!;
        if (!File.Exists(path))
        {
            MessageBox.Show("ClientAppSettings.json no existe.", "Shinigami Launcher");
            return;
        }

        BackupFile(path, "FastFlags");
        File.Delete(path);
        MessageBox.Show("ClientAppSettings.json eliminado. Backup creado.", "Shinigami Launcher");
    }

    // ---------------- Renderer ----------------

    private void ApplyRenderer_Click(object sender, RoutedEventArgs e)
    {
        var flags = ReadFlagsDictionary();

        foreach (var key in new[]
        {
            "FFlagDebugGraphicsPreferD3D11",
            "FFlagDebugGraphicsPreferVulkan",
            "FFlagDebugGraphicsPreferOpenGL"
        })
            flags.Remove(key);

        var choice = (RendererCombo.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Automatic";

        if (choice == "Direct3D 11")
            flags["FFlagDebugGraphicsPreferD3D11"] = "True";
        else if (choice == "Vulkan")
            flags["FFlagDebugGraphicsPreferVulkan"] = "True";
        else if (choice == "OpenGL")
            flags["FFlagDebugGraphicsPreferOpenGL"] = "True";

        WriteFlags(flags);
    }


    // ---------------- Mods / multiple instances ----------------

    private void LoadMultipleInstanceState()
    {
        try
        {
            var flags = ReadFlagsDictionary();
            if (MultipleInstancesToggle != null)
                MultipleInstancesToggle.IsChecked =
                    flags.TryGetValue("FLogWndProcessCheck", out var value) && value == "0";
        }
        catch
        {
            if (MultipleInstancesToggle != null)
                MultipleInstancesToggle.IsChecked = false;
        }
    }

    private void MultipleInstancesToggle_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var flags = ReadFlagsDictionary();

            if (MultipleInstancesToggle.IsChecked == true)
                flags["FLogWndProcessCheck"] = "0";
            else
                flags.Remove("FLogWndProcessCheck");

            WriteFlags(flags);

            SidebarStatus.Text =
                (_versionDir != null ? $"Roblox: Detectado\nVersión: {_versionDir.Name}" : "Roblox: No detectado")
                + $"\nMúltiples instancias: {(MultipleInstancesToggle.IsChecked == true ? "Activadas" : "Desactivadas")}";
        }
        catch (Exception ex)
        {
            MessageBox.Show($"No pude cambiar múltiples instancias:\n{ex.Message}", "Shinigami Launcher");
        }
    }

    private void OpenModsFolder_Click(object sender, RoutedEventArgs e)
    {
        if (!RequireRoblox()) return;

        var modsPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "ShinigamiLauncher",
            "Mods"
        );

        Directory.CreateDirectory(modsPath);
        OpenFolder(modsPath);
    }

    private void ModsHelp_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show(
            "La sección Mods administra personalizaciones locales del launcher.\n\n" +
            "Múltiples instancias usa FLogWndProcessCheck = 0. " +
            "Las demás opciones visuales pueden ampliarse después con paquetes de archivos.",
            "Ayuda de Mods"
        );
    }

    private void Compatibility_Click(object sender, RoutedEventArgs e)
    {
        if (!RequireRoblox()) return;

        var exe = Path.Combine(_versionDir!.FullName, "RobloxPlayerBeta.exe");
        try
        {
            Process.Start(new ProcessStartInfo(
                "rundll32.exe",
                $"shell32.dll,Control_RunDLL appwiz.cpl,,0"
            ) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show($"No pude abrir compatibilidad:\n{ex.Message}", "Shinigami Launcher");
        }
    }

    private void OpenFontsPage_Click(object sender, RoutedEventArgs e)
    {
        ShowPage(FontsPage);
    }

    private void About_Click(object sender, RoutedEventArgs e)
    {
        MessageBox.Show(
            "Shinigami Roblox Launcher\n\n" +
            "Launcher local WPF con FPS, FastFlags, presets, fuentes, mods y backups.",
            "Acerca de"
        );
    }

    // ---------------- UI fonts ----------------

    private void LoadSystemFonts()
    {
        var families = Fonts.SystemFontFamilies
            .Select(f => f.Source)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x)
            .ToList();

        UiFontCombo.ItemsSource = families;
        UiFontCombo.SelectedItem = families.Contains("Segoe UI") ? "Segoe UI" : families.FirstOrDefault();

        if (UiFontCombo.SelectedItem is string selectedFamily)
        {
            var ff = new FontFamily(selectedFamily);
            UiFontPreviewTitle.FontFamily = ff;
            UiFontPreviewUpper.FontFamily = ff;
            UiFontPreviewLower.FontFamily = ff;
            UiFontPreviewSymbols.FontFamily = ff;
        }
    }

    private void UiFontCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (UiFontCombo.SelectedItem is not string family) return;

        var ff = new FontFamily(family);
        UiFontPreviewTitle.FontFamily = ff;
        UiFontPreviewUpper.FontFamily = ff;
        UiFontPreviewLower.FontFamily = ff;
        UiFontPreviewSymbols.FontFamily = ff;
    }

    private void ApplyUiFont_Click(object sender, RoutedEventArgs e)
    {
        if (UiFontCombo.SelectedItem is not string family) return;
        FontFamily = new FontFamily(family);
    }

    // ---------------- Roblox fonts ----------------

    private void RefreshRobloxFonts()
    {
        RobloxFontTargetCombo.Items.Clear();

        if (!RequireRoblox()) return;

        var dir = RobloxFontsPath!;
        if (!Directory.Exists(dir))
        {
            FontStatusText.Text = $"No existe la carpeta: {dir}";
            return;
        }

        var files = Directory.GetFiles(dir)
            .Where(p =>
                string.Equals(Path.GetExtension(p), ".ttf", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(Path.GetExtension(p), ".otf", StringComparison.OrdinalIgnoreCase))
            .Select(Path.GetFileName)
            .OrderBy(x => x)
            .ToList();

        foreach (var file in files)
            RobloxFontTargetCombo.Items.Add(file);

        if (RobloxFontTargetCombo.Items.Count > 0)
            RobloxFontTargetCombo.SelectedIndex = 0;

        FontStatusText.Text = $"{files.Count} fuentes de Roblox detectadas.";
    }

    private void RefreshRobloxFonts_Click(object sender, RoutedEventArgs e) => RefreshRobloxFonts();

    private void ChooseCustomFont_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Filter = "Fuentes (*.ttf;*.otf)|*.ttf;*.otf|Todos (*.*)|*.*"
        };

        if (dlg.ShowDialog() != true) return;

        _selectedExternalFont = dlg.FileName;
        CustomFontPathText.Text = dlg.FileName;

        try
        {
            // WPF can preview a font from its folder URI + #family name only if we know family name.
            // Load using GlyphTypeface to discover the family.
            var glyph = new GlyphTypeface(new Uri(dlg.FileName));
            var familyName = glyph.FamilyNames.Values.FirstOrDefault();

            if (!string.IsNullOrWhiteSpace(familyName))
            {
                var folder = Path.GetDirectoryName(dlg.FileName)!.Replace("\\", "/");
                var ff = new FontFamily(new Uri($"file:///{folder}/"), $"./#{familyName}");
                ExternalFontPreviewTitle.FontFamily = ff;
                ExternalFontPreviewAlphabet.FontFamily = ff;
                FontStatusText.Text = $"Vista previa: {familyName}";
            }
            else
            {
                FontStatusText.Text = "Fuente seleccionada. No pude detectar el nombre de familia para la vista previa.";
            }
        }
        catch
        {
            FontStatusText.Text = "Fuente seleccionada. WPF no pudo previsualizarla, pero aún puedes aplicarla.";
        }
    }

    private void ApplyRobloxFont_Click(object sender, RoutedEventArgs e)
    {
        if (!RequireRoblox()) return;

        if (RobloxFontTargetCombo.SelectedItem is not string targetName)
        {
            MessageBox.Show("Selecciona una fuente de Roblox.", "Shinigami Launcher");
            return;
        }

        if (string.IsNullOrWhiteSpace(_selectedExternalFont) || !File.Exists(_selectedExternalFont))
        {
            MessageBox.Show("Selecciona un archivo .ttf/.otf.", "Shinigami Launcher");
            return;
        }

        var target = Path.Combine(RobloxFontsPath!, targetName);
        if (!File.Exists(target))
        {
            MessageBox.Show("La fuente objetivo ya no existe.", "Shinigami Launcher");
            return;
        }

        BackupFile(target, "Fonts");
        File.Copy(_selectedExternalFont, target, true);

        MessageBox.Show(
            $"Fuente aplicada sobre:\n{targetName}\n\nRoblox puede restaurarla después de una actualización.",
            "Shinigami Launcher"
        );
    }

    private void RestoreRobloxFont_Click(object sender, RoutedEventArgs e)
    {
        if (!RequireRoblox()) return;

        if (RobloxFontTargetCombo.SelectedItem is not string targetName)
        {
            MessageBox.Show("Selecciona la fuente que quieres restaurar.", "Shinigami Launcher");
            return;
        }

        var backup = LatestBackup(targetName, "Fonts");
        if (backup == null)
        {
            MessageBox.Show("No hay backup para esa fuente.", "Shinigami Launcher");
            return;
        }

        var target = Path.Combine(RobloxFontsPath!, targetName);
        File.Copy(backup, target, true);

        MessageBox.Show($"Fuente restaurada:\n{targetName}", "Shinigami Launcher");
    }

    // ---------------- Bottom actions ----------------

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var flags = ReadFlagsDictionary();

            if (MultipleInstancesToggle.IsChecked == true)
                flags["FLogWndProcessCheck"] = "0";
            else
                flags.Remove("FLogWndProcessCheck");

            WriteFlags(flags);
            MessageBox.Show("Configuración guardada.", "Shinigami Launcher");
        }
        catch (Exception ex)
        {
            MessageBox.Show($"No pude guardar:\n{ex.Message}", "Shinigami Launcher");
        }
    }

    private void SaveAndLaunch_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var flags = ReadFlagsDictionary();

            if (MultipleInstancesToggle.IsChecked == true)
                flags["FLogWndProcessCheck"] = "0";
            else
                flags.Remove("FLogWndProcessCheck");

            WriteFlags(flags);
        }
        catch
        {
            // Launch can still continue if settings could not be written.
        }

        if (TrackActivityToggle.IsChecked == true)
            SidebarStatus.Text =
                (_versionDir != null ? $"Roblox: {_versionDir.Name}" : "Roblox no detectado")
                + "\nSeguimiento: activo";

        LaunchRoblox_Click(sender, e);
    }

    private void Close_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

}
