SHINIGAMI LAUNCHER - RINNEGAN FINAL

El Rinnegan se usa como icono del instalador, icono del launcher y logo de toda la app.

Para crear el EXE final:
1. Extrae la carpeta.
2. Abre: Build Shinigami Setup.vbs
3. Espera a que termine.
4. Pulsa: Abrir Release

Archivo final:
Release\ShinigamiSetup.exe

Ese es el único archivo que necesitas compartir.
