$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$logPath = Join-Path $root "build_log.txt"

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="Shinigami Builder"
        Width="620" Height="380"
        ResizeMode="NoResize"
        WindowStartupLocation="CenterScreen"
        Background="#0A0B10"
        Foreground="#F7F7FB">
    <Grid Margin="24">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <TextBlock Text="SHINIGAMI BUILDER"
                   FontSize="25"
                   FontWeight="Bold"
                   Foreground="#A78BFA"/>

        <TextBlock Grid.Row="1"
                   Name="StatusText"
                   Text="Preparando..."
                   Margin="0,12,0,0"
                   FontSize="14"/>

        <ProgressBar Grid.Row="2"
                     Name="Progress"
                     Height="10"
                     Margin="0,16,0,0"
                     Minimum="0"
                     Maximum="100"
                     Value="5"
                     Foreground="#8B5CF6"/>

        <TextBox Grid.Row="3"
                 Name="LogBox"
                 Margin="0,16,0,0"
                 Background="#11131A"
                 Foreground="#B9C0CF"
                 BorderBrush="#2B3040"
                 IsReadOnly="True"
                 TextWrapping="Wrap"
                 VerticalScrollBarVisibility="Auto"/>

        <StackPanel Grid.Row="4"
                    Orientation="Horizontal"
                    HorizontalAlignment="Right"
                    Margin="0,16,0,0">
            <Button Name="OpenButton"
                    Content="Abrir Release"
                    IsEnabled="False"
                    Background="#8B5CF6"
                    Foreground="White"
                    BorderThickness="0"
                    Padding="16,9"
                    Margin="0,0,8,0"/>
            <Button Name="CloseButton"
                    Content="Cerrar"
                    Background="#20232C"
                    Foreground="White"
                    BorderThickness="0"
                    Padding="16,9"/>
        </StackPanel>
    </Grid>
</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader ([xml]$xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)

$status = $window.FindName("StatusText")
$progress = $window.FindName("Progress")
$logBox = $window.FindName("LogBox")
$openButton = $window.FindName("OpenButton")
$closeButton = $window.FindName("CloseButton")

$closeButton.Add_Click({ $window.Close() })
$openButton.Add_Click({
    $release = Join-Path $root "Release"
    if (Test-Path $release) { Start-Process explorer.exe $release }
})

function UI([string]$message, [int]$value = -1) {
    $window.Dispatcher.Invoke([action]{
        $status.Text = $message
        if ($value -ge 0) { $progress.Value = $value }
    })
}

function Log([string]$message) {
    Add-Content -Path $logPath -Value $message
    $window.Dispatcher.Invoke([action]{
        $logBox.AppendText($message + [Environment]::NewLine)
        $logBox.ScrollToEnd()
    })
}

function Has-DotNet8 {
    try {
        $sdks = & dotnet --list-sdks 2>$null
        return [bool]($sdks | Select-String "^8\.")
    } catch {
        return $false
    }
}

$script:buildDone = $false

$window.Add_ContentRendered({
    $window.Dispatcher.InvokeAsync([action]{
        try {
            if (Test-Path $logPath) { Remove-Item $logPath -Force }

            UI "Comprobando .NET 8 SDK..." 8
            Log "Comprobando .NET 8 SDK..."

            if (-not (Has-DotNet8)) {
                $answer = [System.Windows.MessageBox]::Show(
                    "Se necesita .NET 8 SDK para crear el instalador.`n`n¿Quieres instalarlo automáticamente?",
                    "Shinigami Builder",
                    [System.Windows.MessageBoxButton]::YesNo,
                    [System.Windows.MessageBoxImage]::Information
                )

                if ($answer -ne [System.Windows.MessageBoxResult]::Yes) {
                    Start-Process "https://dotnet.microsoft.com/en-us/download/dotnet/8.0"
                    throw "Falta .NET 8 SDK."
                }

                $winget = Get-Command winget -ErrorAction SilentlyContinue
                if (-not $winget) {
                    Start-Process "https://dotnet.microsoft.com/en-us/download/dotnet/8.0"
                    throw "WinGet no está disponible. Se abrió la página oficial de .NET."
                }

                UI "Instalando .NET 8 SDK..." 15
                Log "Instalando Microsoft.DotNet.SDK.8 con WinGet..."

                $p = Start-Process winget -ArgumentList @(
                    "install",
                    "--id", "Microsoft.DotNet.SDK.8",
                    "--exact",
                    "--accept-package-agreements",
                    "--accept-source-agreements"
                ) -Wait -PassThru

                if ($p.ExitCode -ne 0) {
                    throw "WinGet terminó con código $($p.ExitCode)."
                }

                [System.Windows.MessageBox]::Show(
                    ".NET 8 SDK se instaló.`n`nCierra este builder y vuelve a abrirlo para continuar.",
                    "Shinigami Builder",
                    [System.Windows.MessageBoxButton]::OK,
                    [System.Windows.MessageBoxImage]::Information
                ) | Out-Null
                return
            }

            $launcherProj = Join-Path $root "ShinigamiLauncher\ShinigamiLauncher.csproj"
            $installerProj = Join-Path $root "ShinigamiInstaller\ShinigamiInstaller.csproj"
            $payloadDir = Join-Path $root "ShinigamiInstaller\Payload"
            $releaseDir = Join-Path $root "Release"

            New-Item -ItemType Directory -Force -Path $payloadDir | Out-Null
            New-Item -ItemType Directory -Force -Path $releaseDir | Out-Null

            UI "Compilando Shinigami Launcher..." 30
            Log "Compilando launcher self-contained..."

            $launcherArgs = @(
                "publish", $launcherProj,
                "-c", "Release",
                "-r", "win-x64",
                "--self-contained", "true",
                "/p:PublishSingleFile=true",
                "/p:IncludeNativeLibrariesForSelfExtract=true"
            )

            $launcherOutput = & dotnet @launcherArgs 2>&1
            foreach ($line in $launcherOutput) { Log "$line" }
            if ($LASTEXITCODE -ne 0) { throw "Falló la compilación del launcher." }

            $launcherExe = Join-Path $root "ShinigamiLauncher\bin\Release\net8.0-windows\win-x64\publish\ShinigamiLauncher.exe"
            if (-not (Test-Path $launcherExe)) { throw "No se encontró el EXE del launcher después de compilar." }

            Copy-Item -Force $launcherExe (Join-Path $payloadDir "ShinigamiLauncher.exe")

            UI "Creando instalador gráfico..." 68
            Log "Compilando instalador self-contained..."

            $installerArgs = @(
                "publish", $installerProj,
                "-c", "Release",
                "-r", "win-x64",
                "--self-contained", "true",
                "/p:PublishSingleFile=true",
                "/p:IncludeNativeLibrariesForSelfExtract=true"
            )

            $installerOutput = & dotnet @installerArgs 2>&1
            foreach ($line in $installerOutput) { Log "$line" }
            if ($LASTEXITCODE -ne 0) { throw "Falló la compilación del instalador." }

            $setupExe = Join-Path $root "ShinigamiInstaller\bin\Release\net8.0-windows\win-x64\publish\ShinigamiSetup.exe"
            if (-not (Test-Path $setupExe)) { throw "No se encontró ShinigamiSetup.exe después de compilar." }

            Copy-Item -Force $setupExe (Join-Path $releaseDir "ShinigamiSetup.exe")

            UI "¡Listo! ShinigamiSetup.exe fue creado." 100
            Log ""
            Log "LISTO: Release\ShinigamiSetup.exe"
            $openButton.IsEnabled = $true
            $script:buildDone = $true
        }
        catch {
            UI "Error durante la compilación." 100
            Log ""
            Log "ERROR: $($_.Exception.Message)"
            $openButton.IsEnabled = Test-Path (Join-Path $root "Release")

            [System.Windows.MessageBox]::Show(
                "Ocurrió un error al crear el instalador.`n`n$($_.Exception.Message)`n`nRevisa build_log.txt para más detalles.",
                "Shinigami Builder",
                [System.Windows.MessageBoxButton]::OK,
                [System.Windows.MessageBoxImage]::Error
            ) | Out-Null
        }
    }) | Out-Null
})

$window.ShowDialog() | Out-Null
