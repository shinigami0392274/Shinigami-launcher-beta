using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;

namespace ShinigamiInstaller;

public partial class MainWindow : Window
{
    private bool _spanish = true;
    private string InstallDir => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "ShinigamiLauncher"
    );

    private string InstalledExe => Path.Combine(InstallDir, "ShinigamiLauncher.exe");

    public MainWindow()
    {
        InitializeComponent();
    }

    private void Continue_Click(object sender, RoutedEventArgs e)
    {
        _spanish = !((LanguageCombo.SelectedItem as ComboBoxItem)?.Content?.ToString()?.Contains("English") ?? false);
        ApplyLanguage();
        LanguagePage.Visibility = Visibility.Collapsed;
        WelcomePage.Visibility = Visibility.Visible;
    }

    private void ApplyLanguage()
    {
        if (_spanish)
        {
            WelcomeTitle.Text = "Bienvenido a Shinigami Launcher";
            WelcomeDescription.Text = "El launcher definitivo para personalizar y optimizar Roblox.";
            Feature1.Text = "✓  FPS y rendimiento";
            Feature2.Text = "✓  Presets y FastFlags";
            Feature3.Text = "✓  Mods, fuentes y múltiples instancias";
            Feature4.Text = "✓  Backups y restauración";
            DesktopShortcutCheck.Content = "Crear acceso directo en el escritorio";
            StartMenuShortcutCheck.Content = "Crear acceso directo en el menú Inicio";
            InstallButton.Content = "Instalar";
            InstallingTitle.Text = "Instalando Shinigami Launcher";
            InstallingDescription.Text = "No cierres esta ventana.";
            DoneTitle.Text = "¡Listo!";
            DoneDescription.Text = "Shinigami Launcher se instaló correctamente.";
            DoneShortcutText.Text = "✓ Accesos directos creados según tu selección";
            LaunchNowButton.Content = "Iniciar ahora";
            FinishButton.Content = "Finalizar";

        }
        else
        {
            WelcomeTitle.Text = "Welcome to Shinigami Launcher";
            WelcomeDescription.Text = "A clean launcher for customizing and optimizing Roblox.";
            Feature1.Text = "✓  FPS and performance";
            Feature2.Text = "✓  Presets and FastFlags";
            Feature3.Text = "✓  Mods, fonts and multiple instances";
            Feature4.Text = "✓  Backups and restore";
            DesktopShortcutCheck.Content = "Create a desktop shortcut";
            StartMenuShortcutCheck.Content = "Create a Start Menu shortcut";
            InstallButton.Content = "Install";
            InstallingTitle.Text = "Installing Shinigami Launcher";
            InstallingDescription.Text = "Do not close this window.";
            DoneTitle.Text = "Done!";
            DoneDescription.Text = "Shinigami Launcher was installed successfully.";
            DoneShortcutText.Text = "✓ Shortcuts created according to your selection";
            LaunchNowButton.Content = "Launch now";
            FinishButton.Content = "Finish";

        }
    }

    private async void Install_Click(object sender, RoutedEventArgs e)
    {
        WelcomePage.Visibility = Visibility.Collapsed;
        InstallPage.Visibility = Visibility.Visible;

        try
        {
            await Task.Run(() => InstallApplication());

            Dispatcher.Invoke(() =>
            {
                Progress.Value = 100;
                InstallStatus.Text = _spanish ? "Instalación completada." : "Installation complete.";
                InstallPage.Visibility = Visibility.Collapsed;
                DonePage.Visibility = Visibility.Visible;
            });
        }
        catch (Exception ex)
        {
            Dispatcher.Invoke(() =>
            {
                MessageBox.Show(
                    (_spanish ? "No se pudo instalar:\n" : "Installation failed:\n") + ex.Message,
                    "Shinigami Launcher",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
                InstallPage.Visibility = Visibility.Collapsed;
                WelcomePage.Visibility = Visibility.Visible;
            });
        }
    }

    private void InstallApplication()
    {
        Dispatcher.Invoke(() =>
        {
            InstallStatus.Text = _spanish ? "Preparando archivos..." : "Preparing files...";
            Progress.Value = 15;
        });

        Directory.CreateDirectory(InstallDir);

        var asm = Assembly.GetExecutingAssembly();
        var resourceName = asm.GetManifestResourceNames()
            .FirstOrDefault(x => x.EndsWith("Payload.ShinigamiLauncher.exe", StringComparison.OrdinalIgnoreCase));

        if (resourceName == null)
            throw new InvalidOperationException(
                _spanish
                    ? "El instalador no contiene ShinigamiLauncher.exe. Compila el paquete con build_clean_release.ps1."
                    : "Installer payload is missing. Build the package using build_clean_release.ps1."
            );

        Dispatcher.Invoke(() =>
        {
            InstallStatus.Text = _spanish ? "Instalando aplicación..." : "Installing application...";
            Progress.Value = 45;
        });

        using (var input = asm.GetManifestResourceStream(resourceName)
                           ?? throw new InvalidOperationException("Payload stream missing."))
        using (var output = File.Create(InstalledExe))
        {
            input.CopyTo(output);
        }

        Dispatcher.Invoke(() =>
        {
            InstallStatus.Text = _spanish ? "Creando accesos directos..." : "Creating shortcuts...";
            Progress.Value = 75;
        });

        if (DesktopShortcutCheck.Dispatcher.Invoke(() => DesktopShortcutCheck.IsChecked == true))
        {
            CreateShortcut(
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "Shinigami Launcher.lnk")
            );
        }

        if (StartMenuShortcutCheck.Dispatcher.Invoke(() => StartMenuShortcutCheck.IsChecked == true))
        {
            var folder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.Programs),
                "Shinigami Launcher"
            );
            Directory.CreateDirectory(folder);
            CreateShortcut(Path.Combine(folder, "Shinigami Launcher.lnk"));
        }

        Dispatcher.Invoke(() => Progress.Value = 95);
    }

    private void CreateShortcut(string shortcutPath)
    {
        var shellType = Type.GetTypeFromProgID("WScript.Shell")
                        ?? throw new InvalidOperationException("WScript.Shell unavailable.");

        dynamic shell = Activator.CreateInstance(shellType)!;
        dynamic shortcut = shell.CreateShortcut(shortcutPath);
        shortcut.TargetPath = InstalledExe;
        shortcut.WorkingDirectory = InstallDir;
        shortcut.IconLocation = InstalledExe + ",0";
        shortcut.Description = "Shinigami Roblox Launcher";
        shortcut.Save();
    }

    private void LaunchNow_Click(object sender, RoutedEventArgs e)
    {
        if (File.Exists(InstalledExe))
            Process.Start(new ProcessStartInfo(InstalledExe) { UseShellExecute = true });
        Close();
    }

    private void Close_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }
}
